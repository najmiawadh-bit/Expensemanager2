# Expense Manager - Android Kotlin + Jetpack Compose Project

This is a complete, production-ready Android Studio project featuring:
- **Jetpack Compose (Material 3)** for modern UI layout
- **Room Database** for persistent local transaction storage
- **Google Mobile Ads (AdMob)** for Banner & Interstitial ads
- **Google Play Billing Library v6** for $0.99 1-Year Remove Ads Subscription
- **Google Drive API v3** for Cloud Backup & Restore

## How to Run in Android Studio
1. Open Android Studio (Hedgehog 2023.1.1 or newer).
2. Select **Open** and choose this project folder.
3. Wait for Gradle Sync to finish.
4. Run on an Android Emulator or connected device (API 24+ / Android 7.0+).
