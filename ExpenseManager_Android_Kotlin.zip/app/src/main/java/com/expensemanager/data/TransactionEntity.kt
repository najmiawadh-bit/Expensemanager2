package com.expensemanager.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "transactions")
data class TransactionEntity(
    @PrimaryKey val id: String,
    val type: String, // "income" or "expense"
    val amount: Double,
    val currency: String,
    val categoryId: String,
    val date: String, // ISO YYYY-MM-DD
    val note: String,
    val createdAt: Long = System.currentTimeMillis()
)